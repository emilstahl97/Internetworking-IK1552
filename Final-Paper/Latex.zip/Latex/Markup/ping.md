\chapter{Results of benchmarking RTT with ICMP}


\section{17-ffaa:0:1107,[0.0.0.0] 192.33.93.195}

# Our AP
## Results for 17-ffaa:0:1107,[0.0.0.0] 192.33.93.195

### SCION traceroute to 17-ffaa:0:1107,[0.0.0.0]

scion traceroute 17-ffaa:0:1107,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107] MTU: 1472 NextHop: 127.0.0.1:30001

* 0 17-ffaa:1:fa8,127.0.0.1:0 IfID=1 7.025ms 1.77ms 13.582ms
* 1 17-ffaa:0:1107,192.33.93.195:0 IfID=460 64.057ms 43.097ms 51.18ms


### Results of SCION pinging 17-ffaa:0:1107,[0.0.0.0] 192.33.93.195

scion ping -c 10  17-ffaa:0:1107,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107] MTU: 1472 NextHop: 127.0.0.1:30001

PING 17-ffaa:0:1107,0.0.0.0:0 pld=0B scion_pkt=80B
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=0 time=44.196ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=1 time=54.306ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=2 time=45.239ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=3 time=37.129ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=4 time=38.608ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=5 time=40.357ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=6 time=35.293ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=7 time=37.06ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=8 time=35.525ms
88 bytes from 17-ffaa:0:1107,0.0.0.0: scmp_seq=9 time=44.055ms

--- 17-ffaa:0:1107,0.0.0.0 statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9.063135s

### Results of pinging 192.33.93.195 with IPv4 at Swiss Federal Institute of Technology Zurich

ping 192.33.93.195 -c 10
PING 192.33.93.195 (192.33.93.195) 56(84) bytes of data.
64 bytes from 192.33.93.195: icmp_seq=1 ttl=47 time=26.0 ms
64 bytes from 192.33.93.195: icmp_seq=2 ttl=47 time=25.9 ms
64 bytes from 192.33.93.195: icmp_seq=3 ttl=47 time=26.1 ms
64 bytes from 192.33.93.195: icmp_seq=4 ttl=47 time=25.9 ms
64 bytes from 192.33.93.195: icmp_seq=5 ttl=47 time=26.0 ms
64 bytes from 192.33.93.195: icmp_seq=6 ttl=47 time=25.9 ms
64 bytes from 192.33.93.195: icmp_seq=7 ttl=47 time=25.9 ms
64 bytes from 192.33.93.195: icmp_seq=8 ttl=47 time=26.0 ms
64 bytes from 192.33.93.195: icmp_seq=9 ttl=47 time=26.1 ms
64 bytes from 192.33.93.195: icmp_seq=10 ttl=47 time=26.0 ms

--- 192.33.93.195 ping statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9010ms
rtt min/avg/max/mdev = 25.915/25.983/26.100/0.067 ms

---------------------------

## Results for 16-ffaa:0:1001,[0.0.0.0] 141.44.17.129 at scionlab.ovgu.de

### SCION traceroute to 16-ffaa:0:1001,[0.0.0.0]

8:~$ scion traceroute 16-ffaa:0:1001,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107 1>4 17-ffaa:0:1102 2>3 17-ffaa:0:1108 2>8 17-ffaa:0:1101 6>4 19-ffaa:0:1301 1>2 16-ffaa:0:1001] MTU: 1472 NextHop: 127.0.0.1:30001

0 17-ffaa:1:fa8,127.0.0.1:0 IfID=1 2.175ms 27.409ms 13.606ms
1 17-ffaa:0:1107,192.33.93.195:0 IfID=460 57.126ms 55.356ms 38.132ms
2 17-ffaa:0:1107,192.33.93.195:0 IfID=1 40.765ms 42.785ms 41.093ms
3 17-ffaa:0:1102,129.132.121.164:0 IfID=4 50.414ms 38.169ms 41.135ms
4 17-ffaa:0:1102,192.33.92.146:0 IfID=2 43.233ms 44.184ms 49.285ms
5 17-ffaa:0:1108,195.176.0.237:0 IfID=3 41.193ms 40.364ms 52.413ms
6 17-ffaa:0:1108,195.176.28.157:0 IfID=2 76.983ms 43.422ms 44.007ms
7 17-ffaa:0:1101,193.247.172.154:0 IfID=8 44.75ms 44.273ms 47.116ms
8 17-ffaa:0:1101,193.247.172.154:0 IfID=6 43.639ms 68.886ms 43.668ms
9 19-ffaa:0:1301,141.44.17.129:0 IfID=4 64.521ms 63.204ms 61.62ms
10 19-ffaa:0:1301,141.44.17.129:0 IfID=1 62.169ms 78.652ms 64.237ms
11 16-ffaa:0:1001,172.31.0.23:0 IfID=2 74.365ms 91.417ms 70.19ms
  
### Results of SCION pinging 16-ffaa:0:1001,[0.0.0.0]

scion ping -c 10  16-ffaa:0:1001,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107 1>4 17-ffaa:0:1102 3>4 17-ffaa:0:1108 9>7 19-ffaa:0:1301 2>2 16-ffaa:0:1002 4>6 16-ffaa:0:1004 3>5 16-ffaa:0:1001] MTU: 1472 NextHop: 127.0.0.1:30001

PING 16-ffaa:0:1001,0.0.0.0:0 pld=0B scion_pkt=172B
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=0 time=280.794ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=1 time=276.525ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=2 time=272.155ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=3 time=265.887ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=4 time=273.519ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=5 time=276.745ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=6 time=274.704ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=7 time=263.755ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=8 time=271.424ms
180 bytes from 16-ffaa:0:1001,0.0.0.0: scmp_seq=9 time=277.651ms

--- 16-ffaa:0:1001,0.0.0.0 statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9.282741s

### Results of pinging 141.44.17.129 with IPv4 at scionlab.ovgu.de

ping -c 10 141.44.17.129
PING 141.44.17.129 (141.44.17.129) 56(84) bytes of data.
64 bytes from 141.44.17.129: icmp_seq=1 ttl=51 time=31.3 ms
64 bytes from 141.44.17.129: icmp_seq=2 ttl=51 time=31.2 ms
64 bytes from 141.44.17.129: icmp_seq=3 ttl=51 time=31.2 ms
64 bytes from 141.44.17.129: icmp_seq=4 ttl=51 time=31.3 ms
64 bytes from 141.44.17.129: icmp_seq=5 ttl=51 time=31.2 ms
64 bytes from 141.44.17.129: icmp_seq=6 ttl=51 time=31.3 ms
64 bytes from 141.44.17.129: icmp_seq=7 ttl=51 time=31.2 ms
64 bytes from 141.44.17.129: icmp_seq=8 ttl=51 time=31.3 ms
64 bytes from 141.44.17.129: icmp_seq=9 ttl=51 time=31.3 ms
64 bytes from 141.44.17.129: icmp_seq=10 ttl=51 time=31.3 ms

--- 141.44.17.129 ping statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9010ms
rtt min/avg/max/mdev = 31.211/31.250/31.310/0.026 ms

-------------------------------

## Results for 18-ffaa:0:1206,[0.0.0.0] 

### SCION traceroute to 18-ffaa:0:1206,[0.0.0.0] 

scion traceroute  18-ffaa:0:1206,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107 1>4 17-ffaa:0:1102 2>3 17-ffaa:0:1108 9>7 19-ffaa:0:1301 4>6 17-ffaa:0:1101 5>4 18-ffaa:0:1201 8>1 18-ffaa:0:1206] MTU: 1472 NextHop: 127.0.0.1:30001

0 17-ffaa:1:fa8,127.0.0.1:0 IfID=1 5.622ms 10.781ms 23.443ms
1 17-ffaa:0:1107,192.33.93.195:0 IfID=460 40.874ms 69.872ms 51.402ms
2 17-ffaa:0:1107,192.33.93.195:0 IfID=1 37.854ms 40.992ms 36.306ms
3 17-ffaa:0:1102,129.132.121.164:0 IfID=4 45.264ms 37.162ms 38.34ms
4 17-ffaa:0:1102,192.33.92.146:0 IfID=2 42.62ms 33.324ms 48.191ms
5 17-ffaa:0:1108,195.176.0.237:0 IfID=3 45.988ms 39.985ms 41.966ms
6 17-ffaa:0:1108,195.176.28.157:0 IfID=9 48.209ms 42.429ms 43.767ms
7 19-ffaa:0:1301,141.44.17.129:0 IfID=7 68.889ms 72.579ms 72.874ms
8 19-ffaa:0:1301,141.44.17.129:0 IfID=4 65.87ms 62.15ms 58.237ms
9 17-ffaa:0:1101,193.247.172.154:0 IfID=6 84.059ms 84.696ms 76.28ms
10 17-ffaa:0:1101,193.247.172.134:0 IfID=5 86.051ms 101.986ms 92.479ms
11 18-ffaa:0:1201,128.2.24.126:0 IfID=4 188.992ms 189.171ms 192.153ms
12 18-ffaa:0:1201,128.2.24.126:0 IfID=8 191.119ms 186.942ms 198.965ms
13 18-ffaa:0:1206,128.2.24.125:0 IfID=1 192.526ms 186.442ms 207.745ms

### SCION ping to 18-ffaa:0:1206,[0.0.0.0] 

scion ping -c 10 18-ffaa:0:1206,[0.0.0.0]
Resolved local address:
  127.0.0.1
Using path:
  Hops: [17-ffaa:1:fa8 1>460 17-ffaa:0:1107 1>4 17-ffaa:0:1102 3>4 17-ffaa:0:1108 9>7 19-ffaa:0:1301 4>6 17-ffaa:0:1101 5>4 18-ffaa:0:1201 8>1 18-ffaa:0:1206] MTU: 1472 NextHop: 127.0.0.1:30001

PING 18-ffaa:0:1206,0.0.0.0:0 pld=0B scion_pkt=192B
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=0 time=204.291ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=1 time=187.464ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=2 time=200.408ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=3 time=190.865ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=4 time=186.585ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=5 time=187.457ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=6 time=189.874ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=7 time=193.996ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=8 time=193.025ms
200 bytes from 18-ffaa:0:1206,0.0.0.0: scmp_seq=9 time=185.488ms

--- 18-ffaa:0:1206,0.0.0.0 statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9.194803s

### Results of pinging 128.2.24.125 with IPv4 at scion-core.cylab.cmu.edu

ping -c 10 128.2.24.125
PING 128.2.24.125 (128.2.24.125) 56(84) bytes of data.
64 bytes from 128.2.24.125: icmp_seq=1 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=2 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=3 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=4 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=5 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=6 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=7 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=8 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=9 ttl=48 time=117 ms
64 bytes from 128.2.24.125: icmp_seq=10 ttl=48 time=117 ms

--- 128.2.24.125 ping statistics ---
10 packets transmitted, 10 received, 0% packet loss, time 9010ms
rtt min/avg/max/mdev = 116.708/116.809/116.910/0.062 ms




















