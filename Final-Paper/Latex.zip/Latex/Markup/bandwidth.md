
## Results for 16-ffaa:0:1001

### 500 mbps 

scion-bwtestclient -s 16-ffaa:0:1001,[172.31.0.23]:30100 -cs ?,?,?,500000000 -sc ?,?,?,500000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 187500 packets
server->client: 3 seconds, 1000 bytes, 187500 packets

S->C results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 7029333 bps / 7.03 Mbps
Loss rate: 98.6%
Interarrival time min/avg/max/mdev = 0.000/1.181/133.192/11.490 ms

C->S results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 5696000 bps / 5.70 Mbps
Loss rate: 98.9%
Interarrival time min/avg/max/mdev = 0.008/1.403/121.630/10.965 ms

### 10 mbps

scion-bwtestclient -s 16-ffaa:0:1001,[172.31.0.23]:30100 -cs ?,?,?,10000000 -sc ?,?,?,10000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 3750 packets
server->client: 3 seconds, 1000 bytes, 3750 packets

S->C results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 8125333 bps / 8.13 Mbps
Loss rate: 18.7%
Interarrival time min/avg/max/mdev = 0.000/0.987/161.820/12.682 ms

C->S results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 8144000 bps / 8.14 Mbps
Loss rate: 18.6%
Interarrival time min/avg/max/mdev = 0.008/1.035/95.132/9.700 ms

### 1 mbps

scion-bwtestclient -s 16-ffaa:0:1001,[172.31.0.23]:30100 -cs ?,?,?,1000000 -sc ?,?,?,1000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 375 packets
server->client: 3 seconds, 1000 bytes, 375 packets
We need to sleep for 1 seconds before we can get the results

S->C results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 1000000 bps / 1.00 Mbps
Loss rate: 0.0%
Interarrival time min/avg/max/mdev = 0.000/8.082/65.408/7.571 ms

C->S results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 981333 bps / 0.98 Mbps
Loss rate: 1.9%
Interarrival time min/avg/max/mdev = 0.010/8.162/67.037/7.673 ms


## Results for 17-ffaa:0:1107


### 500 mbps

scion-bwtestclient -s 17-ffaa:0:1107,[192.33.93.195]:30100 -cs ?,?,?,500000000 -sc ?,?,?,500000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 187500 packets
server->client: 3 seconds, 1000 bytes, 187500 packets

S->C results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 4362666 bps / 4.36 Mbps
Loss rate: 99.1%
Interarrival time min/avg/max/mdev = 0.000/1.815/213.657/14.555 ms

C->S results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 4149333 bps / 4.15 Mbps
Loss rate: 99.2%
Interarrival time min/avg/max/mdev = 0.004/1.908/330.504/18.127 ms


### 10 mbps

scion-bwtestclient -s 17-ffaa:0:1107,[192.33.93.195]:30100 -cs ?,?,?,10000000 -sc ?,?,?,10000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 3750 packets
server->client: 3 seconds, 1000 bytes, 3750 packets

S->C results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 6498666 bps / 6.50 Mbps
Loss rate: 35.0%
Interarrival time min/avg/max/mdev = 0.000/1.244/187.895/13.662 ms

C->S results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 3933333 bps / 3.93 Mbps
Loss rate: 60.7%
Interarrival time min/avg/max/mdev = 0.004/2.024/95.995/9.694 ms


### 1 mbps

scion-bwtestclient -s 17-ffaa:0:1107,[192.33.93.195]:30100 -cs ?,?,?,1000000 -sc ?,?,?,1000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 375 packets
server->client: 3 seconds, 1000 bytes, 375 packets
We need to sleep for 1 seconds before we can get the results

S->C results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 1000000 bps / 1.00 Mbps
Loss rate: 0.0%
Interarrival time min/avg/max/mdev = 0.000/7.371/51.295/6.628 ms

C->S results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 1000000 bps / 1.00 Mbps
Loss rate: 0.0%
Interarrival time min/avg/max/mdev = 0.004/7.539/49.089/6.446 ms

## Results for 18-ffaa:0:1206,[128.2.24.125]

## 500 mbps

scion-bwtestclient -s 18-ffaa:0:1206,[128.2.24.125]:30100 -cs ?,?,?,500000000 -sc ?,?,?,500000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 187500 packets
server->client: 3 seconds, 1000 bytes, 187500 packets

S->C results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 3104000 bps / 3.10 Mbps
Loss rate: 99.4%
Interarrival time min/avg/max/mdev = 0.000/2.612/459.030/21.364 ms

C->S results
Attempted bandwidth: 500000000 bps / 500.00 Mbps
Achieved bandwidth: 3941333 bps / 3.94 Mbps
Loss rate: 99.2%
Interarrival time min/avg/max/mdev = 0.006/1.989/183.578/13.476 ms

## 10 mbps

scion-bwtestclient -s 18-ffaa:0:1206,[128.2.24.125]:30100 -cs ?,?,?,10000000 -sc ?,?,?,10000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 3750 packets
server->client: 3 seconds, 1000 bytes, 3750 packets

S->C results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 8016000 bps / 8.02 Mbps
Loss rate: 19.8%
Interarrival time min/avg/max/mdev = 0.000/1.025/120.038/10.909 ms

C->S results
Attempted bandwidth: 10000000 bps / 10.00 Mbps
Achieved bandwidth: 8389333 bps / 8.39 Mbps
Loss rate: 16.1%
Interarrival time min/avg/max/mdev = 0.006/0.975/65.640/8.041 ms


## 1 mbps

scion-bwtestclient -s 18-ffaa:0:1206,[128.2.24.125]:30100 -cs ?,?,?,1000000 -sc ?,?,?,1000000

Test parameters:
client->server: 3 seconds, 1000 bytes, 375 packets
server->client: 3 seconds, 1000 bytes, 375 packets

S->C results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 1000000 bps / 1.00 Mbps
Loss rate: 0.0%
Interarrival time min/avg/max/mdev = 0.000/8.061/46.711/6.217 ms

C->S results
Attempted bandwidth: 1000000 bps / 1.00 Mbps
Achieved bandwidth: 1000000 bps / 1.00 Mbps
Loss rate: 0.0%
Interarrival time min/avg/max/mdev = 0.006/8.021/57.069/7.003 ms


















