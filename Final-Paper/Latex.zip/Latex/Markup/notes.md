Topic: Research functionality, feasibility, and maybe performance of SCION.

## Introduction:

### Background
  - importance of internet
  - intro to BGP 
  - need for clean-slate
  - intro to SCION
  - benefits of SCION 

### Problem 
  - Problems of BGP
  - lack of availability and transparency
  - Path control
  - suffers from efficiency and scalability deficiencies; for instance
  - where routing protocol convergence can take minutes or even days.
  - Avoid states

### Purpose 
- Research the need, feasbility, and performance of SCION.

### Goal 

## Background
- Explain background of SCION

## Methodology: 
- SCION
- Isolation Domains
- Control and Data plane
- Dispatcher
- SCION packet


- https://wagnerdevelopment.de/xiondp-thesis.pdf
- distinguishes between control plane and data plane.
- 


### 2.1 Benchmarking environment
### 2.2 Benchmarking metrics

## Results:

- connected to ETHZ-AP in Switzerland ISD 17.
- IP of ETHZ-AP is 192.33.93.195 located at Swiss Federal Institute of Technology Zurich

- Calculate MSS
- Add results of ICMP bandwidth / Matskin Equation.

## Discussion:

- Discuss results
- VM may impact performance, however big difference compared to TCP/IP
- encryption overhead
- limited topology, not richly connected as real internet with peer-to-peer links.
- SCION stateless, so every packet needs separate processing.
- requiring memory references.
- compare to Chandrashekar's results
- mention P4 implementation that achieved high speed, but with a lot of changes.

- packet loss under high load
- https://wagnerdevelopment.de/xiondp-thesis.pdf
- 


## Conclusion:

